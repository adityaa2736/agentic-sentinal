# 🤖 Algorand DeFi Agentic AI 

Welcome to the **Algorand DeFi Agentic AI**! This guide is written to be as comfortable and easy to understand as possible. Whether you are an expert programmer or completely new to coding and blockchain, this document will explain exactly what this program does, why we built it this way, and how all the pieces fit together.

---

## 📖 The Big Picture: What is this?

Imagine you run a bank on the internet (this is called **DeFi**, or Decentralized Finance). Sometimes, bad actors try to hack these banks, or the value of the money suddenly crashes. 

This project acts like an **Automated Security Guard** (an "Agentic AI") that never sleeps. 
- It constantly listens to news and events happening in the DeFi world.
- If it hears something dangerous (like "Hackers stole $5 million!"), it quickly decides how serious the danger is.
- Then, it writes a permanent security alert into a digital public ledger (a **Blockchain** called **Algorand**) so that no hacker can ever erase the warning.
- Finally, it flashes a real-time warning on a beautiful dashboard so users are instantly informed.

---

## 🧩 Exploring the Pieces: How Everything Works

This completely automated system is split into three main parts. Let's look at what each part does:

### 1. 🧠 The "AI Brain" (Python)
This is where the actual thinking happens. We built this part using **Python** (a programming language that is excellent for data and AI).
- **`ai_agent.py`:** This is the logic file. It reads incoming news or events (like "Protocol X just got hacked!"). It scans the text for keywords like *stolen*, *hack*, or *rug pull*. If it finds them, it raises the alarm to **CRITICAL**. If it's just normal news, it stays at **LOW**.
- **`main.py`:** This is the action file. Once the `ai_agent.py` decides the danger level, `main.py` creates a brand-new crypto wallet. It spends exactly `0 ALGO` to send a message to itself. Inside the "note" field of this transaction, it pastes the AI's warning. Because **Algorand** is a blockchain, this warning is now public, permanent, and tamper-proof.

### 2. 🔌 The "Nerve Center" / Backend (`backend/` folder)
The Python Brain is smart, but it needs a way to talk to your computer screen. That's what the **Backend** does. It is written in **Node.js** (JavaScript).
- **Express.js:** This acts like a traffic cop, routing data safely.
- **Socket.io:** This is the real magic. Normally, you have to click "Refresh" on a website to see new information. `Socket.io` creates an open pipe so that the exact second the Python AI detects a threat, the Backend instantly pushes that warning to your screen without you doing anything.

### 3. 🖥️ The Visual Dashboard / Frontend (`frontend/` folder)
This is the beautiful website where you can see the graphs and alerts. It is built using **React** (a very popular tool for building websites).
- **Vite:** A super-fast engine that runs our React website.
- **Tailwind CSS:** The tool we use to drop in colors, margins, and nice designs without dealing with messy CSS files.
- **Recharts:** The library that draws the cool, live-updating charts on your screen.
- **PeraWallet Connect:** A special button that lets you connect your actual Algorand crypto wallet (Pera Wallet) directly to the dashboard, proving it's a real Web3 app!

---

## 🚀 How to Run It Yourself (Step-by-Step)

If you want to see this come to life on your computer, you need to turn on all three parts.

### Step 1: Prepare Your Computer
Make sure you have downloaded and installed **Python 3** and **Node.js** from their official websites. Install the **Pera Wallet App** on your phone if you want to connect it later.

### Step 2: Turn on the "AI Brain"
We need to give Python the tools to talk to Algorand.
1. Open your computer's terminal (or command prompt).
2. Go to the main folder of this project.
3. Type this to install the tools:
   `pip install py-algorand-sdk`
4. Now, run the brain:
   `python main.py`

*(**Important trick:** The AI Brain needs a tiny bit of test money to pay the network fee for its permanent alert. So, when you run `python main.py`, it will print a wallet address. Copy that address, go to the [Algorand Testnet Dispenser website](https://bank.testnet.algorand.network/), and send it some free test ALGO. Then run `python main.py` again!)*

### Step 3: Turn on the "Nerve Center" (Backend)
1. Keep the previous terminal open. Open a **brand new Terminal window**.
2. Navigate into the backend folder by typing:
   `cd backend`
3. Tell it to download all its parts:
   `npm install`
4. Start the server:
   `npm start`

### Step 4: Turn on the Dashboard (Frontend)
1. Open a **third Terminal window**.
2. Navigate into the frontend folder:
   `cd frontend`
3. Download the visual tools:
   `npm install`
4. Start the website:
   `npm run dev`

### 🎯 The Result!
Once Step 4 finishes, the terminal will give you a link (usually `http://localhost:5173`). Open that in your web browser. You can now type a fake "Hack Event" into your Python terminal and watch as the website instantly lights up with a critical warning!

---

We hope this makes exploring the Algorand DeFi Agentic AI a comfortable and exciting experience!
