import json
from algosdk import account, transaction
from algosdk.v2client import algod
from ai_agent import process_defi_event

# Use AlgoNode public API for Testnet
ALGOD_ADDRESS = "https://testnet-api.algonode.cloud"
ALGOD_TOKEN = ""
algod_client = algod.AlgodClient(ALGOD_TOKEN, ALGOD_ADDRESS)

# We generate a new ephemeral account to log the data
private_key, sender_address = account.generate_account()

print(f"=====================================")
print(f" ALGORAND DEFI AGENT INITIALIZED     ")
print(f"=====================================")
print(f"Agent Wallet: {sender_address}")
print(">> Please fund this wallet to pay the 0.001 ALGO fee.")
print(">> Dispenser: https://bank.testnet.algorand.network/")
print(f"=====================================\n")

def push_to_blockchain(ai_analysis):
    """
    Saves the JSON-formatted AI decision directly into the Algorand blockchain.
    """
    try:
        # Prevent failure by checking if the user actually funded the wallet
        acct_info = algod_client.account_info(sender_address)
        if acct_info.get("amount", 0) < 1000:
            print("[X] Insufficient funds! The transaction cannot be sent.")
            print("Action: Copy your wallet address above and paste it in the Testnet Dispenser.")
            return

        print("[*] Wallet funded! Compiling transaction...")
        params = algod_client.suggested_params()
        
        # Serialize the structured AI analysis into a JSON payload for the Note Field
        note_json = json.dumps(ai_analysis)
        
        # Send a 0 ALGO transaction to itself to store the data
        txn = transaction.PaymentTxn(
            sender=sender_address,
            sp=params,
            receiver=sender_address,
            amt=0,
            note=note_json.encode()
        )

        signed_txn = txn.sign(private_key)
        txid = algod_client.send_transaction(signed_txn)
        
        print(f"[*] Transaction Broadcasted! TXID: {txid}")
        print("[*] Waiting for block confirmation (~3 seconds)...")
        tx_info = transaction.wait_for_confirmation(algod_client, txid, 4)
        
        print("\n=== [ DATA IMMUTABLY SAVED TO ALGORAND ] ===")
        print(f"Block Round : {tx_info.get('confirmed-round')}")
        print(f"Explorer URL: https://testnet.explorer.perawallet.app/tx/{txid}")

    except Exception as e:
        print(f"[X] Protocol Error: {e}")

if __name__ == "__main__":
    event_input = input("Enter a DeFi event or anomaly to analyze: ")
    
    # 1. Trigger AI pipeline
    analysis = process_defi_event(event_input)
    print(f"\n--- AI Analysis Result ---")
    print(f"Risk Level   : {analysis['risk_level']}")
    print(f"Action Taken : {analysis['recommended_action']}\n")
    
    # 2. Immutably log to blockchain
    push_to_blockchain(analysis)
