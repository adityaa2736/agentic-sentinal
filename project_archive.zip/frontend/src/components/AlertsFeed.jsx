import React from 'react';

function AlertsFeed({ alerts }) {
  
  if (!alerts || alerts.length === 0) {
    return (
      <div className="glass-panel" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
        <h3 style={{ marginBottom: '15px' }}>Real-time Risk Feed</h3>
        <p style={{ color: 'var(--text-secondary)', fontStyle: 'italic', marginTop: '20px', textAlign: 'center' }}>
          No alerts detected on the network yet. The AI Engine is actively scanning blocks...
        </p>
      </div>
    );
  }

  return (
    <div className="glass-panel" style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
        <h3>Real-time Risk Feed</h3>
        <span className="badge badge-medium">Live</span>
      </div>
      
      <div className="alerts-feed flex-grow">
        {alerts.map((alert, index) => {
          
          let alertClass = 'alert-low';
          let badgeClass = 'badge-low';
          
          if(alert.type === 'CRITICAL') { alertClass = 'alert-critical'; badgeClass = 'badge-critical'; }
          else if(alert.type === 'HIGH') { alertClass = 'alert-high'; badgeClass = 'badge-high'; }
          else if(alert.type === 'MEDIUM') { alertClass = 'alert-medium'; badgeClass = 'badge-medium'; }

          return (
            <div key={`${alert.timestamp}-${index}`} className={`alert-item ${alertClass}`}>
              <div className="alert-header">
                <span className={`badge ${badgeClass}`}>{alert.type} Risk</span>
                <span>{new Date(alert.timestamp).toLocaleTimeString()}</span>
              </div>
              <h4 className="alert-title">{alert.message}</h4>
              <p className="alert-desc">{alert.details}</p>
              
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '10px' }}>
                <span className="alert-action">AI Action: {alert.action}</span>
                {alert.txid && (
                  <a href={alert.explorer} target="_blank" rel="noreferrer" style={{ fontSize: '0.75rem', color: 'var(--accent-primary)', textDecoration: 'none' }}>
                    View Tx On-Chain ↗
                  </a>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  );
}

export default AlertsFeed;
