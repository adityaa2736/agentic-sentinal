import React from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

function Dashboard({ walletAddress, latestAlerts }) {
  // Mock data for the chart representing Algorand Token Price History over recent hours
  const mockChartData = [
    { time: '10:00', price: 0.23 },
    { time: '11:00', price: 0.24 },
    { time: '12:00', price: 0.235 },
    { time: '13:00', price: 0.22 },
    { time: '14:00', price: 0.25 },
    { time: '15:00', price: 0.26 },
    { time: '16:00', price: 0.245 },
  ];

  // Derive stats from latest alerts or mock if none
  const totalAlerts = latestAlerts.length || 0;
  const criticalAlerts = latestAlerts.filter(a => a.type === 'CRITICAL').length;
  const activeScans = walletAddress ? 12 : 5; // Fake number just for UI logic

  return (
    <div className="glass-panel" style={{ minHeight: '80vh' }}>
      <h2 style={{ marginBottom: '20px', fontSize: '1.5rem', fontWeight: 600 }}>DeFi Portfolio & Health</h2>
      
      {!walletAddress && (
        <div style={{ padding: '15px', background: 'rgba(255, 183, 3, 0.1)', border: '1px solid rgba(255, 183, 3, 0.3)', borderRadius: '8px', marginBottom: '24px', color: '#ffb703' }}>
          Connect your Pera Wallet to track personalized portfolio risks and transactions. Showing global network activity.
        </div>
      )}

      {/* Top Stats */}
      <div className="stats-row">
        <div className="glass-panel stat-card" style={{ padding: '16px' }}>
          <span className="stat-title">Active Scans</span>
          <span className="stat-value text-primary" style={{ color: 'var(--accent-primary)' }}>{activeScans} Protocols</span>
        </div>
        <div className="glass-panel stat-card" style={{ padding: '16px' }}>
          <span className="stat-title">Threats Blocked/Logged</span>
          <span className="stat-value text-danger" style={{ color: criticalAlerts > 0 ? 'var(--accent-danger)' : 'white' }}>{criticalAlerts}</span>
        </div>
        <div className="glass-panel stat-card" style={{ padding: '16px' }}>
          <span className="stat-title">Recent Alerts</span>
          <span className="stat-value">{totalAlerts}</span>
        </div>
      </div>

      {/* Chart Segment */}
      <div style={{ marginTop: '20px', borderTop: '1px solid var(--glass-border)', paddingTop: '20px' }}>
        <h3 style={{ marginBottom: '15px', fontSize: '1.2rem', color: 'var(--text-secondary)' }}>Algorand Price Volatility & Event Overlays</h3>
        <div className="chart-container">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={mockChartData}>
              <defs>
                <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00f0ff" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#00f0ff" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <XAxis dataKey="time" stroke="#a1a1aa" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis stroke="#a1a1aa" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(val) => `$${val}`} />
              <Tooltip 
                contentStyle={{ background: 'rgba(10, 5, 20, 0.95)', border: '1px solid rgba(255, 255, 255, 0.1)', borderRadius: '12px' }}
                itemStyle={{ color: '#00f0ff', fontWeight: 600 }}
              />
              <Area type="monotone" dataKey="price" stroke="#00f0ff" fillOpacity={1} fill="url(#colorPrice)" strokeWidth={3} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
