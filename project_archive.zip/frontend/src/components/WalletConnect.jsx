import React from 'react';
import { PeraWalletConnect } from '@perawallet/connect';

// Initialize Pera Wallet externally
const peraWallet = new PeraWalletConnect();

function WalletConnect({ walletAddress, setWalletAddress }) {

  const handleConnectWalletClick = async () => {
    try {
      const newAccounts = await peraWallet.connect();
      peraWallet.connector?.on('disconnect', handleDisconnectWalletClick);
      if (newAccounts.length > 0) {
        setWalletAddress(newAccounts[0]);
      }
    } catch (error) {
      if (error?.data?.type !== "USER_REJECT") {
        console.error(error);
      }
    }
  };

  const handleDisconnectWalletClick = () => {
    peraWallet.disconnect();
    setWalletAddress(null);
  };

  if (walletAddress) {
    return (
      <button className="btn btn-outline" onClick={handleDisconnectWalletClick}>
        Disconnect {walletAddress.slice(0, 6)}...{walletAddress.slice(-4)}
      </button>
    );
  }

  return (
    <button className="btn btn-primary" onClick={handleConnectWalletClick}>
      Connect Pera Wallet
    </button>
  );
}

export default WalletConnect;
