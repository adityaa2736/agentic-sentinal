import React, { useState, useEffect } from 'react';
import Dashboard from './components/Dashboard';
import AlertsFeed from './components/AlertsFeed';
import WalletConnect from './components/WalletConnect';
import { io } from 'socket.io-client';
import { Shield } from 'lucide-react';

const socket = io('http://localhost:5000'); // Connect to Node.js Gateway

function App() {
  const [walletAddress, setWalletAddress] = useState(null);
  const [alerts, setAlerts] = useState([]);
  const [agentStatus, setAgentStatus] = useState("Initializing AI Engine...");
  
  useEffect(() => {
    socket.on('connect', () => {
      setAgentStatus("AI Agent Connected & Monitoring");
    });

    socket.on('agent_status', (data) => {
      setAgentStatus(data.message);
    });

    socket.on('alert', (alertData) => {
      setAlerts(prev => [alertData, ...prev].slice(0, 50)); // Keep last 50 alerts
    });

    socket.on('disconnect', () => {
      setAgentStatus("Connection Lost. Reconnecting...");
    });

    return () => {
      socket.off('connect');
      socket.off('agent_status');
      socket.off('alert');
      socket.off('disconnect');
    };
  }, []);

  return (
    <div className="app-container fade-in">
      <header className="header stagger-1">
        <div className="logo-container">
          <div className="logo-icon">
            <Shield size={28} color="#04020a" strokeWidth={2.5} />
          </div>
          <h1 className="brand-name">AgenticSentinel</h1>
        </div>
        <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
          <WalletConnect walletAddress={walletAddress} setWalletAddress={setWalletAddress} />
        </div>
      </header>

      <div className="agent-status-bar stagger-2">
        <div className="pulse-indicator"></div>
        <span>{agentStatus}</span>
      </div>

      <main className="dashboard-grid stagger-3">
        <div className="main-content">
          <Dashboard walletAddress={walletAddress} latestAlerts={alerts.slice(0,5)} />
        </div>
        <aside className="sidebar stagger-4">
          <AlertsFeed alerts={alerts} />
        </aside>
      </main>
    </div>
  );
}

export default App;
