const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const { monitorAlgorandEvents } = require('./monitor');

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

// Store connected clients
io.on('connection', (socket) => {
    console.log('Frontend connected:', socket.id);
    
    socket.on('disconnect', () => {
        console.log('Frontend disconnected:', socket.id);
    });
});

// Endpoint to manually trigger an AI scan
app.post('/api/trigger', (req, res) => {
    const { event_description, token_id } = req.body;
    // Broadcast manual trigger info to frontends
    io.emit('agent_status', { 
        timestamp: new Date().toISOString(),
        message: `Manual Scan Initiated for ${token_id}...` 
    });
    
    // The monitoring loop naturally handles periodic scans,
    // this endpoint could hit the Python AI service directly if needed.
    res.json({ status: "Scan triggered" });
});

app.get('/api/status', (req, res) => {
    res.json({ status: "Backend active", clients: io.engine.clientsCount });
});

const PORT = 5000;
server.listen(PORT, () => {
    console.log(`Backend Gateway running on port ${PORT}`);
    // Start monitoring blockchain/DeFi events
    monitorAlgorandEvents(io);
});
