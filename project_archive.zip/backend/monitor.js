const axios = require('axios');

const AI_SERVICE_URL = 'http://127.0.0.1:8000/api/v1/analyze';

// Simulated events for demonstration purposes
const simulatedEvents = [
    { event: "Normal transaction volume on ALGO/USDC.", token: "algorand" },
    { event: "Large dump of 1M ALGO detected from whale wallet.", token: "algorand" },
    { event: "Smart contract exploit alert on Yieldly.", token: "yieldly" },
    { event: "High volatility. Minor depeg of USDC.", token: "usdc" },
    { event: "Rug pull warning! Liquidity completely drained from fake ALGO token.", token: "fake-algo" },
    { event: "Steady growth, no anomalies detected.", token: "algorand" }
];

async function trackEvent(io, eventObj) {
    try {
        console.log(`[Monitor] Tracking event: ${eventObj.event}`);
        
        // Notify frontend that Agent is scanning
        io.emit('agent_status', { 
            timestamp: new Date().toISOString(),
            message: `AI Agent analyzing: ${eventObj.event}` 
        });

        // Hit Python AI Service
        const response = await axios.post(AI_SERVICE_URL, {
            event_description: eventObj.event,
            token_id: eventObj.token
        });

        const data = response.data;
        console.log(`[AI Analysis] Risk: ${data.analysis.risk_level}`);

        // Broadcast the result to frontend
        io.emit('alert', {
            type: data.analysis.risk_level, // 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL'
            message: data.analysis.event,
            details: data.analysis.reasoning,
            action: data.analysis.recommended_action,
            txid: data.blockchain_log ? data.blockchain_log.txid : null,
            explorer: data.blockchain_log ? data.blockchain_log.explorer_url : null,
            timestamp: data.analysis.timestamp,
            token: data.analysis.token_id
        });

    } catch (error) {
        console.error(`[Error] Failed to reach AI service: ${error.message}`);
        io.emit('agent_status', { 
            timestamp: new Date().toISOString(),
            message: "Warning: AI Engine Offline." 
        });
    }
}

function monitorAlgorandEvents(io) {
    console.log("Starting Real-time DeFi Event Monitor...");
    let eventIndex = 0;

    // Simulate blockchain event polling every 15 seconds
    setInterval(() => {
        const eventObj = simulatedEvents[eventIndex];
        trackEvent(io, eventObj);
        
        eventIndex = (eventIndex + 1) % simulatedEvents.length;
    }, 15000); // 15 seconds
}

module.exports = { monitorAlgorandEvents };
