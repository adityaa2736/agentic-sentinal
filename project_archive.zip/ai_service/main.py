from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from analyzer import risk_analyzer
from algo_logger import algo_logger
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="DeFi AI Monitoring Agent")

# Allow requests from the frontend and Node backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class EventRequest(BaseModel):
    event_description: str
    token_id: str = "algorand"

@app.get("/")
def root():
    return {"status": "AI Agent Service is running."}

@app.post("/api/v1/analyze")
def analyze_event(req: EventRequest):
    """
    Analyzes an event description against market data and returns a risk assessment.
    Automatically logs high/critical risk events to the Algorand blockchain.
    """
    try:
        # Run AI analysis
        analysis = risk_analyzer.analyze_event(req.event_description, req.token_id)
        
        blockchain_receipt = None
        # Push to blockchain if risk level is Medium, High or Critical to ensure transparency
        if analysis["risk_level"] in ["MEDIUM", "HIGH", "CRITICAL"]:
            blockchain_receipt = algo_logger.log_analysis(analysis)
            
        return {
            "analysis": analysis,
            "blockchain_log": blockchain_receipt
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
