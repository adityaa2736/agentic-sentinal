import json
from algosdk import account, transaction
from algosdk.v2client import algod

# Use AlgoNode public API for Testnet
ALGOD_ADDRESS = "https://testnet-api.algonode.cloud"
ALGOD_TOKEN = ""

class AlgoLogger:
    def __init__(self):
        self.client = algod.AlgodClient(ALGOD_TOKEN, ALGOD_ADDRESS)
        # Generate an ephemeral account or load from env
        self.private_key, self.sender_address = account.generate_account()
        print(f"=== AlgoLogger Initialized ===")
        print(f"Agent Wallet Address: {self.sender_address}")
        print(f"Please fund this wallet via dispenser: https://bank.testnet.algorand.network/")
    
    def log_analysis(self, analysis_data: dict):
        try:
            # Check balance
            acct_info = self.client.account_info(self.sender_address)
            if acct_info.get("amount", 0) < 1000:
                print("[X] Insufficient funds in Agent Wallet. Cannot log to blockchain.")
                return {"status": "error", "message": "Insufficient funds. Please fund the wallet.", "address": self.sender_address}

            params = self.client.suggested_params()
            note_json = json.dumps(analysis_data)
            
            # Send 0 ALGO transaction to self to store note
            txn = transaction.PaymentTxn(
                sender=self.sender_address,
                sp=params,
                receiver=self.sender_address,
                amt=0,
                note=note_json.encode()
            )

            signed_txn = txn.sign(self.private_key)
            txid = self.client.send_transaction(signed_txn)
            
            print(f"[*] Analysis logged! TXID: {txid}")
            # Do not wait for confirmation to avoid blocking the API, return TXID
            return {"status": "success", "txid": txid, "explorer_url": f"https://testnet.explorer.perawallet.app/tx/{txid}"}
        except Exception as e:
            print(f"[X] AlgoLogger Error: {e}")
            return {"status": "error", "message": str(e)}

# Singleton instance
algo_logger = AlgoLogger()
