"""
Risk Analyzer module for DeFi Monitoring.
Analyzes text events and real-time market data to determine risk levels.
"""
import logging
from datetime import datetime, timezone
import requests

# Configure basic logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RiskAnalyzer:
    """Analyzes requested events and matches them with market data to compute a risk score."""

    def __init__(self):
        """Initialize the RiskAnalyzer with CoinGecko base URL."""
        self.coingecko_base = "https://api.coingecko.com/api/v3"

    def fetch_token_data(self, token_id: str):
        """Fetch current price and 24h stats from CoinGecko."""
        try:
            params = {
                "ids": token_id,
                "vs_currencies": "usd",
                "include_24hr_vol": "true",
                "include_24hr_change": "true"
            }
            url = f"{self.coingecko_base}/simple/price"
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            data = response.json()
            if token_id in data:
                return data[token_id]
            return None
        except requests.RequestException as e:
            logger.error("[X] Error fetching token data for %s: %s", token_id, e)
            return None

    def analyze_event(self, event_description: str, token_id: str = "algorand"):
        """
        Analyzes DeFi events and token data to output a structured risk assessment.
        Combines semantic rules with real-time price volatility.
        """
        event = event_description.lower()
        risk_score = 0
        ai_reasoning = []

        # 1. Semantic Analysis (Keyword-based simulation of NLP)
        if any(keyword in event for keyword in ["hack", "exploit", "stolen", "rug pull"]):
            risk_score += 80
            ai_reasoning.append("Critical semantic keywords detected: potential exploit or rug pull.")
        elif any(keyword in event for keyword in ["depeg", "liquidate", "dump", "crash"]):
            risk_score += 50
            ai_reasoning.append("High-risk semantic keywords detected: potential liquidation or dump.")
        elif "alert" in event or "unusual" in event or "anomaly" in event:
            risk_score += 30
            ai_reasoning.append("Suspicious activity keywords detected.")

        # 2. Market Data Analysis (Using CoinGecko)
        market_stats = self.fetch_token_data(token_id)
        if market_stats:
            price_change = market_stats.get('usd_24h_change', 0)
            volatility = abs(price_change) if price_change else 0

            # Calculate risk based on volatility
            if price_change is not None:
                if price_change < -20:
                    risk_score += 60
                    ai_reasoning.append(f"Severe price crash detected: {price_change:.2f}% in 24h.")
                elif price_change < -10:
                    risk_score += 40
                    ai_reasoning.append(f"Significant price drop detected: {price_change:.2f}% in 24h.")
                
                if volatility > 30:
                    risk_score += 30
                    ai_reasoning.append(f"Extremely high volatility detected: {volatility:.2f}%.")
                    
            ai_reasoning.append(f"Current {token_id} Price: ${market_stats.get('usd', 0)}")
        else:
            ai_reasoning.append(f"Could not fetch real-time market data for {token_id}.")

        # Determine Risk Level
        risk_level = "LOW"
        action = "LOG_ONLY"
        
        if risk_score >= 80:
            risk_level = "CRITICAL"
            action = "EMERGENCY_WITHDRAWAL"
        elif risk_score >= 50:
            risk_level = "HIGH"
            action = "MONITOR_CLOSELY"
        elif risk_score >= 30:
            risk_level = "MEDIUM"
            action = "NOTIFY_USER"

        return {
            "timestamp": datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
            "event": event_description,
            "token_id": token_id,
            "risk_score": min(risk_score, 100),
            "risk_level": risk_level,
            "recommended_action": action,
            "reasoning": " ".join(ai_reasoning)
        }

risk_analyzer = RiskAnalyzer()
